# VIP ML Precision Trader

This Flutter app simulates market patterns and auto/manual trading signals using technical indicators (RSI, MACD, Bollinger Bands, etc.).
