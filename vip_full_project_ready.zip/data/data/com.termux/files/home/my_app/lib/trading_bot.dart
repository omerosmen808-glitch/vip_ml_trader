import 'dart:async';
import 'dart:math';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:path_provider/path_provider.dart';
import 'update_service.dart';

class TradingBot extends ChangeNotifier {
  String ssid = '';
  String asset = 'EURUSD';
  double baseAmount = 1.0;
  int duration = 60;
  double totalPL = 0.0;
  double dailyLossLimit = 50.0;
  double dailyProfitLimit = 100.0;
  String lastResult = '';
  List<double> prices = [];
  String prediction = '';
  int signalStrength = 1;
  double probability = 0.0;
  bool autoTrading = false;

  Timer? priceTimer;
  Timer? autoTradeTimer;

  Map<String, dynamic> strategy = {};
  List<Map<String, dynamic>> patternHistory = [];

  TradingBot() {
    _loadLocalStrategy();
    priceTimer = Timer.periodic(Duration(seconds: 5), (_) => _fetchPrice());
  }

  void dispose() {
    priceTimer?.cancel();
    autoTradeTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadLocalStrategy() async {
    final dir = await getApplicationDocumentsDirectory();
    final f = File('\${dir.path}/strategy.json');
    if (await f.exists()) {
      final text = await f.readAsString();
      try {
        strategy = json.decode(text);
      } catch (e) {
        strategy = {};
      }
    }
    notifyListeners();
  }

  void loadConfigFromUpdateService() async {
    await _loadLocalStrategy();
  }

  void _fetchPrice() {
    double price = prices.isNotEmpty ? prices.last : 1.0;
    double volatility = 0.01;
    // allow remote strategy to tweak volatility / randomness for "self-evolving"
    if (strategy.containsKey('rules')) {
      volatility = (strategy['rules']['volatility'] ?? volatility).toDouble();
    }
    double newPrice = price + (Random().nextDouble() - 0.5) * volatility;
    prices.add(newPrice);
    if (prices.length > 200) prices.removeAt(0);
    var analysis = analyzeSignal(prices);
    prediction = analysis['direction'];
    signalStrength = analysis['strength'];
    probability = analysis['probability'];
    notifyListeners();
  }

  // indicators
  double sma(List<double> p, int period) => p.length < period ? p.last : p.sublist(p.length - period).reduce((a, b) => a + b) / period;

  double ema(List<double> p, int period) {
    if (p.length < period) return p.last;
    double k = 2 / (period + 1);
    double e = p[p.length - period];
    for (int i = p.length - period + 1; i < p.length; i++) {
      e = p[i] * k + e * (1 - k);
    }
    return e;
  }

  double rsi(List<double> p, int period) {
    if (p.length < period + 1) return 50.0;
    double gain = 0, loss = 0;
    for (int i = p.length - period; i < p.length; i++) {
      double d = p[i] - p[i - 1];
      if (d > 0) gain += d;
      else loss -= d;
    }
    if (loss == 0) return 100.0;
    double rs = gain / loss;
    return 100 - (100 / (1 + rs));
  }

  double macd(List<double> p) => ema(p, 12) - ema(p, 26);

  Map<String, double> bollinger(List<double> p, int period) {
    if (p.length < period) return {'upper': p.last, 'lower': p.last};
    double m = sma(p, period);
    double sum = p.sublist(p.length - period).map((v) => (v - m) * (v - m)).reduce((a, b) => a + b);
    double std = sqrt(sum / period);
    return {'upper': m + 2 * std, 'lower': m - 2 * std};
  }

  double stochastic(List<double> p, int period) {
    if (p.length < period) return 50.0;
    double high = p.sublist(p.length - period).reduce(max);
    double low = p.sublist(p.length - period).reduce(min);
    return 100 * (p.last - low) / (high - low);
  }

  double momentum(List<double> p, int period) => p.length < period + 1 ? 0.0 : p.last - p[p.length - period - 1];

  Map<String, dynamic> analyzeSignal(List<double> p) {
    final rules = strategy['rules'] ?? {};
    final rsiPeriod = (rules['rsi_period'] ?? 14).toInt();
    final rsiOversold = (rules['rsi_oversold'] ?? 30).toDouble();
    final rsiOverbought = (rules['rsi_overbought'] ?? 70).toDouble();
    final confirmationRequired = (rules['confirmation_required'] ?? 3).toInt();

    if (p.length < 30) return {'direction': 'call', 'strength': 1, 'probability': 50.0};

    int score = 0;
    int confirmations = 0;

    double r = rsi(p, rsiPeriod);
    if (r < rsiOversold) { score += 2; confirmations++; }
    else if (r > rsiOverbought) { score -= 2; confirmations++; }

    double m = macd(p);
    if (m > 0) { score += (rules['macd_positive_weight'] ?? 1).toInt(); confirmations++; }
    else if (m < 0) { score -= 1; confirmations++; }

    double sSMA = sma(p, (rules['sma_period'] ?? 20).toInt());
    double sEMA = ema(p, (rules['ema_period'] ?? 20).toInt());
    if (p.last > sSMA && p.last > sEMA) { score += 1; confirmations++; }
    else if (p.last < sSMA && p.last < sEMA) { score -= 1; confirmations++; }

    var bb = bollinger(p, (rules['bollinger_period'] ?? 20).toInt());
    if (p.last < bb['lower']!) { score += 2; confirmations++; }
    else if (p.last > bb['upper']!) { score -= 2; confirmations++; }

    double st = stochastic(p, (rules['stochastic_period'] ?? 14).toInt());
    if (st < 20) { score += 1; confirmations++; }
    else if (st > 80) { score -= 1; confirmations++; }

    double mo = momentum(p, (rules['momentum_period'] ?? 10).toInt());
    if (mo > 0) { score += 1; confirmations++; }
    else if (mo < 0) { score -= 1; confirmations++; }

    String dir = score > 0 ? 'call' : score < 0 ? 'put' : 'call';
    int strength = score.abs().clamp(1, 5);
    double prob = confirmations / 6 * 100;
    if (confirmations < confirmationRequired) dir = 'none';

    // patternHistory-based adaptation (simple reinforcement)
    for (var h in patternHistory) {
      if (h['direction'] == dir && h['confirmations'] == confirmations && (h['wins'] + h['losses'] > 0)) {
        double winRate = h['wins'] / (h['wins'] + h['losses']);
        strength = (strength * 0.7 + (winRate * 5) * 0.3).round();
        prob = prob * 0.7 + winRate * 100 * 0.3;
      }
    }

    return {'direction': dir, 'strength': strength, 'probability': prob};
  }

  void openTrade({bool manual = false}) {
    if (totalPL <= -dailyLossLimit || totalPL >= dailyProfitLimit) return;
    var signal = analyzeSignal(prices);
    if (signal['direction'] == 'none') {
      lastResult = 'الصفقة ضعيفة، لم يتم فتحها';
      notifyListeners();
      return;
    }

    double amount = baseAmount * (0.5 + 0.1 * signal['strength']);
    double pl = (Random().nextDouble() - 0.5) * amount;
    totalPL += pl;

    bool won = pl > 0;
    var hist = patternHistory.firstWhere(
      (h) => h['direction'] == signal['direction'] && h['confirmations'] == signalStrength,
      orElse: () {
        final map = {'direction': signal['direction'], 'confirmations': signalStrength, 'wins': 0, 'losses': 0};
        patternHistory.add(map);
        return map;
      }
    );
    if (won) hist['wins'] += 1; else hist['losses'] += 1;

    lastResult =
      '\${manual ? "صفقة يدوية" : "صفقة تلقائية"}\nالاتجاه: \${signal['direction']}\nقوة الإشارة: \${signal['strength']}\nاحتمالية الربح: \${signal['probability'].toStringAsFixed(1)}%\nحجم الصفقة: \$amount\nربح/خسارة: \${pl.toStringAsFixed(2)}';

    notifyListeners();
  }

  void startAuto() {
    autoTrading = true;
    autoTradeTimer?.cancel();
    autoTradeTimer = Timer.periodic(Duration(seconds: duration), (_) => openTrade());
    notifyListeners();
  }

  void stopAuto() {
    autoTrading = false;
    autoTradeTimer?.cancel();
    notifyListeners();
  }

  List<charts.Series<double, int>> chartData() => [
    charts.Series<double, int>(
      id: 'Prices',
      colorFn: (_, i) => i % 2 == 0 ? charts.MaterialPalette.green.shadeDefault : charts.MaterialPalette.red.shadeDefault,
      domainFn: (double p, int i) => i,
      measureFn: (double p, _) => p,
      data: prices,
    )
  ];
}
