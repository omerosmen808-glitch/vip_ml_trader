import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'package:charts_flutter/flutter.dart' as charts;

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VIP ML Precision Trader',
      theme: ThemeData.dark(),
      home: HomePage(),
    );
  }
}

// ضع هنا باقي كودك الذي أرسلته مسبقًا
