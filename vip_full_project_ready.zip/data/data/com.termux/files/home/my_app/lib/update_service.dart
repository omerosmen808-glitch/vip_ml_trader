import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// خدمة بسيطة لتحميل استراتيجية/إعدادات من سيرفر خارجي (ملف JSON)
/// ملاحظات أمان: يجب حماية Endpoint الحقيقي وإضافة تحقق توقيع رقمي (HMAC) أو HTTPS + مفاتيح API.
/// هنا نضع مثالاً تعليمياً فقط.
class UpdateService {
  static const _remoteUrlKey = 'update_remote_url';
  static const _versionKey = 'strategy_version';
  static String currentVersion = 'local-1';

  /// نقطة نهاية افتراضية — يجب استبدالها بعنوان سيرفرك الحقيقي.
  static String get defaultRemoteUrl => 'https://example.com/vip_strategy/strategy.json';

  static Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    currentVersion = prefs.getString(_versionKey) ?? 'local-1';
    // create local strategy asset copy into app documents if not exists
    final dir = await getApplicationDocumentsDirectory();
    final target = File('${dir.path}/strategy.json');
    if (!await target.exists()) {
      // copy bundled asset (app should include assets/strategy.json)
      // but since we can't access flutter asset from here, we'll ensure file exists on first run by writing default
      final defaultContent = await _defaultStrategyJson();
      await target.writeAsString(defaultContent);
    }
  }

  /// Periodic check helper
  static void periodicCheck({int intervalMinutes = 5, Function(bool)? onNewConfig}) {
    // In Flutter the persistent periodic timer would normally be set in the app.
    // Here we just expose a helper that callers can use.
    // For simplicity this method does nothing by itself on non-Flutter platforms.
  }

  /// Immediate check for updates. Returns true if new config downloaded.
  static Future<bool> checkNow({String? remoteUrl}) async {
    remoteUrl ??= defaultRemoteUrl;
    try {
      final resp = await http.get(Uri.parse(remoteUrl)).timeout(Duration(seconds: 12));
      if (resp.statusCode != 200) return false;
      final body = resp.body;
      final jsonMap = json.decode(body);
      if (jsonMap is! Map) return false;
      final version = jsonMap['version'] ?? 'remote-unknown';
      final dir = await getApplicationDocumentsDirectory();
      final target = File('${dir.path}/strategy.json');
      // simple version check
      if (version == currentVersion) return false;
      await target.writeAsString(json.encode(jsonMap));
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_versionKey, version.toString());
      currentVersion = version.toString();
      return true;
    } catch (e) {
      // ignore network errors gracefully
      return false;
    }
  }

  static Future<String> _defaultStrategyJson() async {
    final Map<String, dynamic> defaultStrategy = {
      "version": "local-1",
      "rules": {
        "rsi_period": 14,
        "rsi_oversold": 30,
        "rsi_overbought": 70,
        "macd_positive_weight": 1,
        "sma_period": 20,
        "ema_period": 20,
        "bollinger_period": 20,
        "stochastic_period": 14,
        "momentum_period": 10,
        "confirmation_required": 3
      },
      "meta": {
        "author": "VIP ML Team",
        "updated_at": "${DateTime.now().toUtc().toIso8601String()}"
      }
    };
    return json.encode(defaultStrategy);
  }
}
