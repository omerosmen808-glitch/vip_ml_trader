
package com.example.vip_ml_precision_trader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
